
(function(window,document,Laya){
	var __un=Laya.un,__uns=Laya.uns,__static=Laya.static,__class=Laya.class,__getset=Laya.getset,__newvec=Laya.__newvec;

	var Text=laya.display.Text;
//class core.HelloWorld
var HelloWorld=(function(){
	function HelloWorld(){
		console.log("子模块已加载");
		var ret=GameUtil.add(3333,4444);
		console.log("运算结果",ret);
		var user=new UserUI();
		user.init();
	}

	__class(HelloWorld,'core.HelloWorld');
	return HelloWorld;
})()


//class other.UserUI
var UserUI=(function(){
	function UserUI(){}
	__class(UserUI,'other.UserUI');
	var __proto=UserUI.prototype;
	__proto.init=function(){
		console.log("I am user.");
		var t=new Text();
		t.text="5555分包成功66666666666";
		t.color="#ffffff";
		t.pos(33,33);
		t.fontSize=24;
		Laya.stage.addChild(t);
	}

	return UserUI;
})()


//class utils.GameUtil
var GameUtil=(function(){
	function GameUtil(){}
	__class(GameUtil,'utils.GameUtil');
	GameUtil.add=function(a,b){
		return a+b;
	}

	return GameUtil;
})()



})(window,document,Laya);

if (typeof define === 'function' && define.amd){
	define('laya.core', ['require', "exports"], function(require, exports) {
        'use strict';
        Object.defineProperty(exports, '__esModule', { value: true });
        for (var i in Laya) {
			var o = Laya[i];
            o && o.__isclass && (exports[i] = o);
        }
    });
}